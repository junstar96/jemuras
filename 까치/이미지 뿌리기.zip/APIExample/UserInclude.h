#pragma once

/**
	@file		UserInclude.h
	@date		2014/8/25
	@author		Vallista
	@brief		���� �ؾ��� ������ ��Ƶ� ��
*/

#include <assert.h>
#include <Windows.h>
#include <stdlib.h>
#include <string>
#include <math.h>
#include <vector>
#include <map>
#include <list>
#include <algorithm>
#include <gdiplus.h>

#pragma comment(lib, "Gdiplus.lib")

using namespace Gdiplus;
using namespace std;

#include "CSingleton.h"

#include "CScene.h"
#include "CSceneMng.h"

#include "CMain.h"

#include "WinMain.h"